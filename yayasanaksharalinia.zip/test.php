<?php include 'layout/header.php'; ?>
</head>

<body>
    <?php include 'layout/navbar.php' ?>
    <div class="flex w-full h-64 pt-56">
        <div class="w-1/2 border-2 border-red-600">
            <img class="object-center justify-center" src="public/tk/tk-1-b.jpg">
        </div>
        <img class="w-1/2 pr-4" src="public/tk/tk-1-b.jpg">
    </div>


<div class="mt-80">

</div>
    <!--Footer -->
    <?php include 'layout/footer.php'; ?>